// ================================
// src/ui/pages/Online/index.js
// Wrapper fino: delega en lib/mountOnline.js
// Mantiene el mismo punto de entrada para el modo Online.
// Toda la lógica pesada vive ahora en lib/mountOnline.js.
// ================================

export { default } from "./lib/mountOnline.js";
